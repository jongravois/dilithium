MDB-addons are additional scripts and elements of MDB, required in some components.

You don't need to do anything with that. Leave it as it is now. It will work for you behind the scene.